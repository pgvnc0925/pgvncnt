export default function CoreAppLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
